/*
 * server.c - CineVault lightweight HTTP server
 *
 * Serves the web interface from public/ and a small JSON API that calls the
 * linked-list functions in movies.c. Runs on Windows (Winsock, MSYS2/MinGW)
 * and on Linux/macOS (POSIX sockets) from the same source file.
 *
 *   Browser  --HTTP-->  server.c  -->  movies.c (linked list)  -->  data/movies.dat
 *
 * API
 *   GET    /api/movies?q=&genre=&sort=   list (search, filter, sort)
 *   POST   /api/movies                   add a movie
 *   GET    /api/movies/{id}              one movie
 *   PUT    /api/movies/{id}              update a movie
 *   DELETE /api/movies/{id}              delete a movie
 *   GET    /api/stats                    totals, average rating, genres
 *   GET    /api/list                     the linked list as it sits in memory
 */
#define __USE_MINGW_ANSI_STDIO 1   /* C99 printf (%zu, PRIxPTR) on MinGW */

#ifdef _WIN32
#  ifndef WIN32_LEAN_AND_MEAN
#    define WIN32_LEAN_AND_MEAN
#  endif
#  include <winsock2.h>
#  include <ws2tcpip.h>
#  include <direct.h>
   typedef SOCKET sock_t;
#  define CLOSE_SOCKET(s)  closesocket(s)
#  define SHUT_SEND        SD_SEND
#  define MAKE_DIR(p)      _mkdir(p)
#else
#  include <arpa/inet.h>
#  include <errno.h>
#  include <netinet/in.h>
#  include <sys/select.h>
#  include <sys/socket.h>
#  include <sys/stat.h>
#  include <sys/types.h>
#  include <unistd.h>
   typedef int sock_t;
#  define INVALID_SOCKET   (-1)
#  define CLOSE_SOCKET(s)  close(s)
#  define SHUT_SEND        SHUT_WR
#  define MAKE_DIR(p)      mkdir((p), 0755)
#endif

#include <ctype.h>
#include <inttypes.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "movies.h"

#define DEFAULT_PORT        8080
#define DATA_DIR            "data"
#define DATA_FILE           "data/movies.dat"
#define PUBLIC_DIR          "public"
#define MAX_CONNECTIONS     32
#define MAX_REQUEST         (64 * 1024)
#define MAX_STATIC_FILE     (10L * 1024 * 1024)
#define CONNECTION_TIMEOUT  10          /* seconds a client may take to send a request */

static Movie *g_movies = NULL;          /* head of the singly linked list */
static volatile sig_atomic_t g_running = 1;
static const char *g_log_method = "-";
static const char *g_log_path = "-";

/* ================================================================== */
/* Growable text buffer used to build JSON responses                   */
/* ================================================================== */

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} Buf;

static void buf_reserve(Buf *b, size_t extra)
{
    size_t need = b->len + extra + 1;
    size_t cap;
    char *p;
    if (need <= b->cap) return;
    cap = b->cap ? b->cap : 1024;
    while (cap < need) cap *= 2;
    p = (char *)realloc(b->data, cap);
    if (p == NULL) {
        fprintf(stderr, "Out of memory while building a response.\n");
        exit(1);
    }
    b->data = p;
    b->cap = cap;
}

static void buf_append(Buf *b, const char *s, size_t n)
{
    buf_reserve(b, n);
    memcpy(b->data + b->len, s, n);
    b->len += n;
    b->data[b->len] = '\0';
}

static void buf_puts(Buf *b, const char *s)
{
    buf_append(b, s, strlen(s));
}

static void buf_printf(Buf *b, const char *fmt, ...)
{
    va_list ap, ap2;
    int n;
    va_start(ap, fmt);
    va_copy(ap2, ap);
    n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    if (n > 0) {
        buf_reserve(b, (size_t)n);
        vsnprintf(b->data + b->len, (size_t)n + 1, fmt, ap2);
        b->len += (size_t)n;
    }
    va_end(ap2);
}

/* Write s as a JSON string literal, escaping quotes and control characters. */
static void buf_json_string(Buf *b, const char *s)
{
    buf_puts(b, "\"");
    for (; *s; s++) {
        unsigned char c = (unsigned char)*s;
        switch (c) {
        case '"':  buf_puts(b, "\\\""); break;
        case '\\': buf_puts(b, "\\\\"); break;
        case '\n': buf_puts(b, "\\n");  break;
        case '\r': buf_puts(b, "\\r");  break;
        case '\t': buf_puts(b, "\\t");  break;
        default:
            if (c < 0x20) buf_printf(b, "\\u%04x", c);
            else buf_append(b, s, 1);
        }
    }
    buf_puts(b, "\"");
}

static void buf_free(Buf *b)
{
    free(b->data);
    b->data = NULL;
    b->len = b->cap = 0;
}

/* ================================================================== */
/* JSON for movies                                                      */
/* ================================================================== */

static void json_movie_fields(Buf *b, const Movie *m)
{
    buf_printf(b, "\"id\":%d,\"title\":", m->id);
    buf_json_string(b, m->title);
    buf_puts(b, ",\"genre\":");
    buf_json_string(b, m->genre);
    buf_printf(b, ",\"year\":%d,\"rating\":%.1f,\"image\":", m->year, (double)m->rating);
    buf_json_string(b, m->image);
}

static void json_movie(Buf *b, const Movie *m)
{
    buf_puts(b, "{");
    json_movie_fields(b, m);
    buf_puts(b, "}");
}

/* Real memory address of a node, e.g. "0x5581d2a3c2a0", or null. */
static void json_pointer(Buf *b, const void *p)
{
    if (p == NULL) buf_puts(b, "null");
    else buf_printf(b, "\"0x%" PRIxPTR "\"", (uintptr_t)p);
}

/* ================================================================== */
/* HTTP responses                                                       */
/* ================================================================== */

static const char *status_text(int code)
{
    switch (code) {
    case 200: return "OK";
    case 201: return "Created";
    case 400: return "Bad Request";
    case 404: return "Not Found";
    case 405: return "Method Not Allowed";
    case 409: return "Conflict";
    case 413: return "Payload Too Large";
    case 503: return "Service Unavailable";
    default:  return "Internal Server Error";
    }
}

static void send_all(sock_t fd, const char *data, size_t len)
{
    while (len > 0) {
        int chunk = (len > 65536) ? 65536 : (int)len;
        int sent = (int)send(fd, data, chunk, 0);
        if (sent <= 0) return;           /* client went away */
        data += sent;
        len -= (size_t)sent;
    }
}

static void log_request(int status)
{
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    printf("[%02d:%02d:%02d] %-6s %-32s %d\n",
           t ? t->tm_hour : 0, t ? t->tm_min : 0, t ? t->tm_sec : 0,
           g_log_method, g_log_path, status);
}

static void send_response(sock_t fd, int status, const char *content_type,
                          const char *body, size_t body_len)
{
    char header[512];
    int n = snprintf(header, sizeof(header),
                     "HTTP/1.1 %d %s\r\n"
                     "Content-Type: %s\r\n"
                     "Content-Length: %lu\r\n"
                     "Cache-Control: no-store\r\n"
                     "X-Content-Type-Options: nosniff\r\n"
                     "Connection: close\r\n"
                     "\r\n",
                     status, status_text(status), content_type, (unsigned long)body_len);
    send_all(fd, header, (size_t)n);
    if (body != NULL && body_len > 0) send_all(fd, body, body_len);
    log_request(status);
}

static void send_json(sock_t fd, int status, const Buf *b)
{
    send_response(fd, status, "application/json; charset=utf-8", b->data, b->len);
}

/* {"error": "...", "field": "..."} - field tells the form which input to highlight. */
static void send_error(sock_t fd, int status, const char *message, const char *field)
{
    Buf b = {0};
    buf_puts(&b, "{\"error\":");
    buf_json_string(&b, message);
    if (field != NULL) {
        buf_puts(&b, ",\"field\":");
        buf_json_string(&b, field);
    }
    buf_puts(&b, "}");
    send_json(fd, status, &b);
    buf_free(&b);
}

/* ================================================================== */
/* Request parsing                                                      */
/* ================================================================== */

typedef struct {
    char method[8];
    char path[512];
    const char *query;      /* points into the connection buffer */
    size_t query_len;
    const char *body;
    size_t body_len;
} Request;

static int hex_value(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

/* Decode application/x-www-form-urlencoded text ("Dark+Knight%21" -> "Dark Knight!"). */
static void url_decode(const char *src, size_t len, char *out, size_t out_size)
{
    size_t o = 0;
    for (size_t i = 0; i < len && o + 1 < out_size; i++) {
        char c = src[i];
        if (c == '+') {
            c = ' ';
        } else if (c == '%' && i + 2 < len &&hex_value(src[i + 1]) >= 0 && hex_value(src[i + 2]) >= 0) {
            c = (char)(hex_value(src[i + 1]) * 16 + hex_value(src[i + 2]));
            i += 2;
        }
        out[o++] = c;
    }
    out[o] = '\0';
}

/* Find key in "a=1&b=2" data and decode its value into out. Returns 1 if found. */
static int form_get(const char *data, size_t data_len, const char *key,
                    char *out, size_t out_size)
{
    size_t i = 0;
    out[0] = '\0';
    if (data == NULL) return 0;

    while (i < data_len) {
        size_t start = i, eq;
        char name[64];
        while (i < data_len && data[i] != '&') i++;
        eq = start;
        while (eq < i && data[eq] != '=') eq++;

        url_decode(data + start, eq - start, name, sizeof(name));
        if (strcmp(name, key) == 0) {
            if (eq < i) url_decode(data + eq + 1, i - eq - 1, out, out_size);
            return 1;
        }
        i++;                              /* skip the '&' */
    }
    return 0;
}

/* Read "Content-Length: N" from the header block. Returns -1 if it is invalid. */
static long content_length(const char *headers, size_t header_len)
{
    const char *p = headers;
    const char *end = headers + header_len;
    static const char name[] = "content-length:";
    size_t name_len = sizeof(name) - 1;

    while (p < end) {
        const char *line_end = strstr(p, "\r\n");
        if (line_end == NULL || line_end > end) break;
        if ((size_t)(line_end - p) > name_len) {
            size_t k = 0;
            while (k < name_len && tolower((unsigned char)p[k]) == name[k]) k++;
            if (k == name_len) {
                char *num_end;
                long value = strtol(p + name_len, &num_end, 10);
                return (value < 0) ? -1 : value;
            }
        }
        p = line_end + 2;
    }
    return 0;
}

/* Parse "METHOD /path?query HTTP/1.1". Returns 1 on success. */
static int parse_request_line(const char *buf, Request *req)
{
    const char *line_end = strstr(buf, "\r\n");
    const char *sp1, *target, *sp2, *question;
    size_t method_len, target_len, path_len;

    if (line_end == NULL) return 0;
    sp1 = memchr(buf, ' ', (size_t)(line_end - buf));
    if (sp1 == NULL) return 0;
    method_len = (size_t)(sp1 - buf);
    if (method_len == 0 || method_len >= sizeof(req->method)) return 0;
    memcpy(req->method, buf, method_len);
    req->method[method_len] = '\0';

    target = sp1 + 1;
    sp2 = memchr(target, ' ', (size_t)(line_end - target));
    if (sp2 == NULL) return 0;
    target_len = (size_t)(sp2 - target);

    question = memchr(target, '?', target_len);
    path_len = question ? (size_t)(question - target) : target_len;
    if (path_len == 0 || path_len >= sizeof(req->path)) return 0;
    memcpy(req->path, target, path_len);
    req->path[path_len] = '\0';

    req->query = question ? question + 1 : NULL;
    req->query_len = question ? target_len - path_len - 1 : 0;
    return 1;
}

/* ================================================================== */
/* API handlers                                                         */
/* ================================================================== */

typedef struct {
    char title[1024];
    char genre[256];
    char image[1024];
    int year;
    float rating;
} MovieForm;

/* Read and validate the movie fields sent by the browser form. */
static int read_movie_form(sock_t fd, const Request *req, MovieForm *f)
{
    char year_text[32], rating_text[32], err[160];
    const char *field = NULL;
    char *end;
    long year;
    double rating;

    form_get(req->body, req->body_len, "title", f->title, sizeof(f->title));
    form_get(req->body, req->body_len, "genre", f->genre, sizeof(f->genre));
    form_get(req->body, req->body_len, "year", year_text, sizeof(year_text));
    form_get(req->body, req->body_len, "rating", rating_text, sizeof(rating_text));
    form_get(req->body, req->body_len, "image", f->image, sizeof(f->image));

    year = strtol(year_text, &end, 10);
    if (year_text[0] == '\0' || *end != '\0') {
        send_error(fd, 400, "Enter the release year as a number, for example 2021.", "year");
        return 0;
    }
    rating = strtod(rating_text, &end);
    if (rating_text[0] == '\0' || *end != '\0') {
        send_error(fd, 400, "Enter the rating as a number from 0 to 10, for example 7.6.", "rating");
        return 0;
    }

    f->year = (year < 0 || year > 100000) ? -1 : (int)year;
    if (rating >= 0.0 && rating <= 10.0) {
        rating = (double)(long)(rating * 10.0 + 0.5) / 10.0;   /* keep one decimal place */
    }
    f->rating = (float)rating;

    if (!validate_movie(f->title, f->genre, f->year, f->rating, f->image,
                        err, sizeof(err), &field)) {
        send_error(fd, 400, err, field);
        return 0;
    }
    return 1;
}

/* GET /api/movies?q=dark&genre=Action&sort=rating */
static void api_list_movies(sock_t fd, const Request *req)
{
    char query[256], genre[128], sort[32];
    Movie *view;
    Buf b = {0};
    int first = 1;

    form_get(req->query, req->query_len, "q", query, sizeof(query));
    form_get(req->query, req->query_len, "genre", genre, sizeof(genre));
    form_get(req->query, req->query_len, "sort", sort, sizeof(sort));

    /* Search/filter builds a separate list of copies; merge sort then relinks it. */
    view = filter_movies(g_movies, query, genre);
    view = sort_movies(view, sort_key_from_string(sort));

    buf_printf(&b, "{\"count\":%d,\"total\":%d,\"movies\":[",
               count_movies(view), count_movies(g_movies));
    for (const Movie *m = view; m != NULL; m = m->next) {
        if (!first) buf_puts(&b, ",");
        json_movie(&b, m);
        first = 0;
    }
    buf_puts(&b, "]}");

    free_movies(&view);                   /* the copies are no longer needed */
    send_json(fd, 200, &b);
    buf_free(&b);
}

/* POST /api/movies */
static void api_add_movie(sock_t fd, const Request *req)
{
    MovieForm f;
    Movie *node;
    char msg[256];
    Buf b = {0};

    if (!read_movie_form(fd, req, &f)) return;

    if (is_duplicate(g_movies, f.title, f.year, 0)) {
        char clean[TITLE_LEN];
        clean_text(clean, f.title, sizeof(clean));
        snprintf(msg, sizeof(msg), "\"%s\" (%d) is already in your collection.", clean, f.year);
        send_error(fd, 409, msg, "title");
        return;
    }

    node = create_movie(next_movie_id(g_movies), f.title, f.genre, f.year, f.rating, f.image);
    if (node == NULL) {
        send_error(fd, 500, "The server ran out of memory. Restart CineVault and try again.", NULL);
        return;
    }
    insert_movie(&g_movies, node);

    if (!save_movies(g_movies, DATA_FILE)) {
        delete_movie(&g_movies, node->id);        /* undo so memory and file agree */
        send_error(fd, 500, "Couldn't write data/movies.dat. Check that the data folder exists and isn't read-only.", NULL);
        return;
    }

    json_movie(&b, node);
    send_json(fd, 201, &b);
    buf_free(&b);
    printf("           new node #%d at 0x%" PRIxPTR ", list now has %d nodes, saved to %s\n",
           node->id, (uintptr_t)node, count_movies(g_movies), DATA_FILE);
}

/* GET /api/movies/{id} */
static void api_get_movie(sock_t fd, int id)
{
    Movie *node = find_movie(g_movies, id);
    Buf b = {0};
    if (node == NULL) {
        send_error(fd, 404, "That movie isn't in the collection any more.", NULL);
        return;
    }
    json_movie(&b, node);
    send_json(fd, 200, &b);
    buf_free(&b);
}

/* PUT /api/movies/{id} */
static void api_update_movie(sock_t fd, const Request *req, int id)
{
    Movie *node = find_movie(g_movies, id);
    Movie backup;
    MovieForm f;
    char msg[256];
    Buf b = {0};

    if (node == NULL) {
        send_error(fd, 404, "That movie isn't in the collection any more.", NULL);
        return;
    }
    if (!read_movie_form(fd, req, &f)) return;

    if (is_duplicate(g_movies, f.title, f.year, id)) {
        char clean[TITLE_LEN];
        clean_text(clean, f.title, sizeof(clean));
        snprintf(msg, sizeof(msg), "\"%s\" (%d) is already in your collection.", clean, f.year);
        send_error(fd, 409, msg, "title");
        return;
    }

    backup = *node;
    update_movie(g_movies, id, f.title, f.genre, f.year, f.rating, f.image);

    if (!save_movies(g_movies, DATA_FILE)) {
        Movie *next = node->next;
        *node = backup;                            /* restore the old values */
        node->next = next;
        send_error(fd, 500, "Couldn't write data/movies.dat. Check that the data folder exists and isn't read-only.", NULL);
        return;
    }

    json_movie(&b, node);
    send_json(fd, 200, &b);
    buf_free(&b);
}

/* DELETE /api/movies/{id} */
static void api_delete_movie(sock_t fd, int id)
{
    Movie *prev = NULL;
    Movie *node = detach_movie(&g_movies, id, &prev);   /* unlink, don't free yet */
    Buf b = {0};

    if (node == NULL) {
        send_error(fd, 404, "That movie isn't in the collection any more.", NULL);
        return;
    }
    if (!save_movies(g_movies, DATA_FILE)) {
        relink_movie(&g_movies, node, prev);          /* put it back */
        send_error(fd, 500, "Couldn't write data/movies.dat. Check that the data folder exists and isn't read-only.", NULL);
        return;
    }

    buf_printf(&b, "{\"deleted\":%d}", id);
    send_json(fd, 200, &b);
    buf_free(&b);
    printf("           freed node #%d at 0x%" PRIxPTR ", list now has %d nodes\n",
           id, (uintptr_t)node, count_movies(g_movies));
    free(node);
}

/* GET /api/stats */
static void api_stats(sock_t fd)
{
    GenreCount genres[MAX_GENRES];
    int genre_total = genre_counts(g_movies, genres, MAX_GENRES);
    int total = count_movies(g_movies);
    const Movie *top = top_rated(g_movies);
    int oldest = 0, newest = 0;
    Buf b = {0};

    for (const Movie *m = g_movies; m != NULL; m = m->next) {
        if (oldest == 0 || m->year < oldest) oldest = m->year;
        if (m->year > newest) newest = m->year;
    }

    buf_printf(&b, "{\"total\":%d,\"average\":%.2f,\"top\":", total, (double)average_rating(g_movies));
    if (top) json_movie(&b, top);
    else buf_puts(&b, "null");

    buf_puts(&b, ",\"genres\":[");
    for (int i = 0; i < genre_total; i++) {
        if (i > 0) buf_puts(&b, ",");
        buf_puts(&b, "{\"name\":");
        buf_json_string(&b, genres[i].name);
        buf_printf(&b, ",\"count\":%d}", genres[i].count);
    }
    if (total > 0) buf_printf(&b, "],\"oldest\":%d,\"newest\":%d}", oldest, newest);
    else buf_puts(&b, "],\"oldest\":null,\"newest\":null}");

    send_json(fd, 200, &b);
    buf_free(&b);
}

/* GET /api/list - every node in list order with its address and next pointer. */
static void api_list_view(sock_t fd)
{
    Buf b = {0};
    buf_puts(&b, "{\"head\":");
    json_pointer(&b, g_movies);
    buf_printf(&b, ",\"nodeSize\":%lu,\"nodes\":[", (unsigned long)sizeof(Movie));
    for (const Movie *m = g_movies; m != NULL; m = m->next) {
        if (m != g_movies) buf_puts(&b, ",");
        buf_puts(&b, "{");
        json_movie_fields(&b, m);
        buf_puts(&b, ",\"addr\":");
        json_pointer(&b, m);
        buf_puts(&b, ",\"next\":");
        json_pointer(&b, m->next);
        buf_puts(&b, "}");
    }
    buf_puts(&b, "]}");
    send_json(fd, 200, &b);
    buf_free(&b);
}

/* "/api/movies/12" -> 12, or 0 if the id part is not a plain number. */
static int parse_id(const char *s)
{
    long id = 0;
    int digits = 0;
    for (; *s; s++, digits++) {
        if (!isdigit((unsigned char)*s) || digits >= 9) return 0;
        id = id * 10 + (*s - '0');
    }
    return digits ? (int)id : 0;
}

static void handle_api(sock_t fd, const Request *req)
{
    const char *m = req->method;

    if (strcmp(req->path, "/api/movies") == 0) {
        if (strcmp(m, "GET") == 0) api_list_movies(fd, req);
        else if (strcmp(m, "POST") == 0) api_add_movie(fd, req);
        else send_error(fd, 405, "Use GET or POST on /api/movies.", NULL);
    } else if (strncmp(req->path, "/api/movies/", 12) == 0) {
        int id = parse_id(req->path + 12);
        if (id <= 0) send_error(fd, 404, "Movie ids are whole numbers, for example /api/movies/3.", NULL);
        else if (strcmp(m, "GET") == 0) api_get_movie(fd, id);
        else if (strcmp(m, "PUT") == 0) api_update_movie(fd, req, id);
        else if (strcmp(m, "DELETE") == 0) api_delete_movie(fd, id);
        else send_error(fd, 405, "Use GET, PUT or DELETE on /api/movies/{id}.", NULL);
    } else if (strcmp(req->path, "/api/stats") == 0 && strcmp(m, "GET") == 0) {
        api_stats(fd);
    } else if (strcmp(req->path, "/api/list") == 0 && strcmp(m, "GET") == 0) {
        api_list_view(fd);
    } else {
        send_error(fd, 404, "There is no API route at this address.", NULL);
    }
}

/* ================================================================== */
/* Static files (the web interface)                                     */
/* ================================================================== */

static const char *mime_type(const char *path)
{
    const char *dot = strrchr(path, '.');
    if (dot == NULL) return "application/octet-stream";
    if (strcmp(dot, ".html") == 0) return "text/html; charset=utf-8";
    if (strcmp(dot, ".css") == 0)  return "text/css; charset=utf-8";
    if (strcmp(dot, ".js") == 0)   return "text/javascript; charset=utf-8";
    if (strcmp(dot, ".json") == 0) return "application/json; charset=utf-8";
    if (strcmp(dot, ".svg") == 0)  return "image/svg+xml";
    if (strcmp(dot, ".png") == 0)  return "image/png";
    if (strcmp(dot, ".jpg") == 0 || strcmp(dot, ".jpeg") == 0) return "image/jpeg";
    if (strcmp(dot, ".webp") == 0) return "image/webp";
    if (strcmp(dot, ".ico") == 0)  return "image/x-icon";
    if (strcmp(dot, ".txt") == 0)  return "text/plain; charset=utf-8";
    return "application/octet-stream";
}

static void send_not_found(sock_t fd)
{
    static const char msg[] = "Not found";
    send_response(fd, 404, "text/plain; charset=utf-8", msg, sizeof(msg) - 1);
}

static void serve_static(sock_t fd, const char *path)
{
    char file_path[600];
    FILE *fp;
    long size;
    char *data;

    if (strcmp(path, "/") == 0) path = "/index.html";

    /* Only plain paths inside public/: no "..", backslashes or drive letters. */
    if (path[0] != '/' || strstr(path, "..") || strchr(path, '\\') || strchr(path, ':')) {
        send_not_found(fd);
        return;
    }

    snprintf(file_path, sizeof(file_path), "%s%s", PUBLIC_DIR, path);
    fp = fopen(file_path, "rb");
    if (fp == NULL) {
        send_not_found(fd);
        return;
    }
    if (fseek(fp, 0, SEEK_END) != 0 || (size = ftell(fp)) < 0 || size > MAX_STATIC_FILE ||
        fseek(fp, 0, SEEK_SET) != 0) {
        fclose(fp);
        send_not_found(fd);
        return;
    }
    data = (char *)malloc((size_t)size + 1);
    if (data == NULL || fread(data, 1, (size_t)size, fp) != (size_t)size) {
        free(data);
        fclose(fp);
        send_not_found(fd);               /* also covers paths that are folders */
        return;
    }
    fclose(fp);
    send_response(fd, 200, mime_type(path), data, (size_t)size);
    free(data);
}

/* ================================================================== */
/* Connections                                                          */
/* ================================================================== */

typedef struct {
    int active;
    sock_t fd;
    char *buf;              /* MAX_REQUEST + 1 bytes */
    size_t len;
    time_t opened;
} Conn;

static Conn g_conns[MAX_CONNECTIONS];

static void conn_close(Conn *c)
{
    shutdown(c->fd, SHUT_SEND);
    CLOSE_SOCKET(c->fd);
    free(c->buf);
    c->buf = NULL;
    c->len = 0;
    c->active = 0;
}

static void handle_request(sock_t fd, Request *req)
{
    g_log_method = req->method;
    g_log_path = req->path;

    if (strncmp(req->path, "/api/", 5) == 0) {
        handle_api(fd, req);
    } else if (strcmp(req->method, "GET") == 0) {
        serve_static(fd, req->path);
    } else {
        send_error(fd, 405, "Only GET is allowed for pages and files.", NULL);
    }
    g_log_method = "-";
    g_log_path = "-";
}

/* Read whatever has arrived; once the whole request is in, answer it and close. */
static void conn_read(Conn *c)
{
    char *header_end;
    size_t header_len;
    long body_len;
    Request req;
    int n = (int)recv(c->fd, c->buf + c->len, (int)(MAX_REQUEST - c->len), 0);

    if (n <= 0) {                         /* closed by the client, or an error */
        conn_close(c);
        return;
    }
    c->len += (size_t)n;
    c->buf[c->len] = '\0';

    header_end = strstr(c->buf, "\r\n\r\n");
    if (header_end == NULL) {
        if (c->len >= MAX_REQUEST) {
            send_error(c->fd, 413, "The request is too large.", NULL);
            conn_close(c);
        }
        return;                           /* headers not complete yet */
    }

    header_len = (size_t)(header_end - c->buf) + 4;
    body_len = content_length(c->buf, header_len);
    if (body_len < 0 || header_len + (size_t)body_len > MAX_REQUEST) {
        send_error(c->fd, 413, "The request is too large.", NULL);
        conn_close(c);
        return;
    }
    if (c->len < header_len + (size_t)body_len) return;   /* body still arriving */

    memset(&req, 0, sizeof(req));
    if (!parse_request_line(c->buf, &req)) {
        send_error(c->fd, 400, "The request could not be read.", NULL);
        conn_close(c);
        return;
    }
    req.body = c->buf + header_len;
    req.body_len = (size_t)body_len;
    c->buf[header_len + (size_t)body_len] = '\0';

    handle_request(c->fd, &req);
    conn_close(c);
}

static void accept_connection(sock_t listener)
{
    sock_t fd = accept(listener, NULL, NULL);
    if (fd == INVALID_SOCKET) return;

    for (int i = 0; i < MAX_CONNECTIONS; i++) {
        Conn *c = &g_conns[i];
        if (!c->active) {
            c->buf = (char *)malloc(MAX_REQUEST + 1);
            if (c->buf == NULL) break;
            c->fd = fd;
            c->len = 0;
            c->opened = time(NULL);
            c->active = 1;
            return;
        }
    }
    CLOSE_SOCKET(fd);                     /* too many open connections */
}

/* ================================================================== */
/* Startup and shutdown                                                 */
/* ================================================================== */

static void on_signal(int sig)
{
    (void)sig;
    g_running = 0;
}

static void print_banner(void)
{
    printf("\n");
    printf("   ____ _            __     __          _ _   \n");
    printf("  / ___(_)_ __   ___ \\ \\   / /_ _ _   _| | |_ \n");
    printf(" | |   | | '_ \\ / _ \\ \\ \\ / / _` | | | | | __|\n");
    printf(" | |___| | | | |  __/  \\ V / (_| | |_| | | |_ \n");
    printf("  \\____|_|_| |_|\\___|   \\_/ \\__,_|\\__,_|_|\\__|\n");
    printf("\n  Movie Collection Manager - C, singly linked list, file handling\n\n");
}

int main(int argc, char *argv[])
{
    int port = DEFAULT_PORT;
    int loaded, freed;
    sock_t listener;
    struct sockaddr_in addr;
    FILE *check;

    if (argc > 1) {
        char *end;
        long p = strtol(argv[1], &end, 10);
        if (*end != '\0' || p < 1 || p > 65535) {
            fprintf(stderr, "Usage: %s [port]   (default %d)\n", argv[0], DEFAULT_PORT);
            return 1;
        }
        port = (int)p;
    }
    setvbuf(stdout, NULL, _IONBF, 0);     /* show log lines immediately */
    print_banner();

    /* 1-5. Open movies.dat and rebuild the linked list from its records. */
    MAKE_DIR(DATA_DIR);                   /* fine if it already exists */
    loaded = load_movies(&g_movies, DATA_FILE);
    if (loaded < 0) printf("  No %s yet. Starting with an empty collection.\n", DATA_FILE);
    else printf("  Loaded %d movies from %s into the linked list.\n", loaded, DATA_FILE);

    check = fopen(PUBLIC_DIR "/index.html", "rb");
    if (check == NULL) {
        printf("  Warning: %s/index.html not found. Start CineVault from the CineVault folder\n"
               "  so it can find the web interface.\n", PUBLIC_DIR);
    } else {
        fclose(check);
    }

    /* 6. Start the HTTP server. */
#ifdef _WIN32
    {
        WSADATA wsa;
        if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
            fprintf(stderr, "  Could not start Winsock.\n");
            free_movies(&g_movies);
            return 1;
        }
    }
#else
    signal(SIGPIPE, SIG_IGN);             /* a closed browser tab must not kill the server */
#endif
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    listener = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (listener == INVALID_SOCKET) {
        fprintf(stderr, "  Could not create a network socket.\n");
        free_movies(&g_movies);
        return 1;
    }
#ifndef _WIN32
    {
        int yes = 1;
        setsockopt(listener, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    }
#endif

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons((unsigned short)port);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);     /* only this computer can connect */

    if (bind(listener, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(listener, 16) != 0) {
        fprintf(stderr, "\n  Could not start on port %d. Another program may be using it.\n"
                        "  Close that program, or start CineVault on another port, for example:\n"
                        "      cinevault 8081\n\n", port);
        CLOSE_SOCKET(listener);
        free_movies(&g_movies);
#ifdef _WIN32
        WSACleanup();
#endif
        return 1;
    }

    printf("\n  CineVault is running at http://localhost:%d\n", port);
    printf("  Open that address in your browser. Press Ctrl+C to stop.\n\n");

    /* 7-8. Serve the interface and process requests until Ctrl+C. */
    while (g_running) {
        fd_set readable;
        sock_t max_fd = listener;
        struct timeval tv;
        int ready;
        time_t now;

        FD_ZERO(&readable);
        FD_SET(listener, &readable);
        for (int i = 0; i < MAX_CONNECTIONS; i++) {
            if (g_conns[i].active) {
                FD_SET(g_conns[i].fd, &readable);
                if (g_conns[i].fd > max_fd) max_fd = g_conns[i].fd;
            }
        }
        tv.tv_sec = 1;                    /* wake up every second to check g_running */
        tv.tv_usec = 0;

        ready = select((int)(max_fd + 1), &readable, NULL, NULL, &tv);
        if (ready < 0) {
#ifdef _WIN32
            if (WSAGetLastError() == WSAEINTR) continue;
#else
            if (errno == EINTR) continue;
#endif
            fprintf(stderr, "  select() failed, stopping.\n");
            break;
        }

        if (ready > 0) {
            for (int i = 0; i < MAX_CONNECTIONS; i++) {
                if (g_conns[i].active && FD_ISSET(g_conns[i].fd, &readable)) conn_read(&g_conns[i]);
            }
            if (FD_ISSET(listener, &readable)) accept_connection(listener);
        }

        /* Drop clients that opened a connection but never finished a request. */
        now = time(NULL);
        for (int i = 0; i < MAX_CONNECTIONS; i++) {
            if (g_conns[i].active && now - g_conns[i].opened > CONNECTION_TIMEOUT) conn_close(&g_conns[i]);
        }
    }

    /* 9. Free memory and close resources. */
    printf("\n  Stopping CineVault...\n");
    for (int i = 0; i < MAX_CONNECTIONS; i++) {
        if (g_conns[i].active) conn_close(&g_conns[i]);
    }
    CLOSE_SOCKET(listener);
    freed = free_movies(&g_movies);
    printf("  Freed %d movie nodes. Your collection is saved in %s.\n\n", freed, DATA_FILE);
#ifdef _WIN32
    WSACleanup();
#endif
    return 0;
}
